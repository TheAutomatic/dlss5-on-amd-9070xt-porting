vit_attention_fused_960_bytein_bout:    ; @vit_attention_fused_960_bytein_bout
; %bb.0:
	s_load_b64 s[2:3], s[0:1], 0x18
	s_wait_kmcnt 0x0
	s_cmp_eq_u64 s[2:3], 0
	s_cselect_b32 s4, -1, 0
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_b32 vcc_lo, exec_lo, s4
	s_cbranch_vccnz .LBB9_2
; %bb.1:
	s_load_b32 s2, s[2:3], 0x0
	s_wait_kmcnt 0x0
	s_cmp_eq_u32 s2, 0
	s_cselect_b32 s4, -1, 0
.LBB9_2:                                ; %Flow147
	s_delay_alu instid0(SALU_CYCLE_1)
	s_and_not1_b32 vcc_lo, exec_lo, s4
	s_cbranch_vccnz .LBB9_7
; %bb.3:
	s_cmp_gt_u32 ttmp9, 0x77f
	s_cbranch_scc1 .LBB9_7
; %bb.4:
	s_load_b128 s[0:3], s[0:1], 0x0
	v_dual_mov_b32 v24, 0x3c003c00 :: v_dual_and_b32 v3, 15, v0
	s_lshr_b32 s4, ttmp9, 1
	v_lshrrev_b32_e32 v2, 1, v0
	s_mov_b32 s5, 0
	s_delay_alu instid0(VALU_DEP_2)
	v_and_or_b32 v1, 0x3f0, s4, v3
	s_lshl_b32 s4, ttmp9, 5
	v_mov_b32_e32 v16, 0
	s_wait_alu 0xfffe
	s_and_b32 s4, s4, 0x3e0
	v_and_b32_e32 v33, 8, v2
	v_dual_mov_b32 v25, v24 :: v_dual_lshlrev_b32 v32, 10, v1
	v_dual_mov_b32 v27, v24 :: v_dual_lshlrev_b32 v0, 9, v0
	v_dual_mov_b32 v17, v16 :: v_dual_mov_b32 v18, v16
	s_delay_alu instid0(VALU_DEP_2)
	v_dual_mov_b32 v19, v16 :: v_dual_and_b32 v0, 0x2000, v0
	v_dual_mov_b32 v20, v16 :: v_dual_mov_b32 v21, v16
	s_wait_kmcnt 0x0
	s_wait_alu 0xfffe
	s_add_nc_u64 s[6:7], s[4:5], s[0:1]
	v_dual_mov_b32 v22, v16 :: v_dual_mov_b32 v23, v16
	v_add_co_u32 v1, s5, s6, v32
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v2, null, s7, 0, s5
	v_or3_b32 v34, v0, s4, v3
	v_add_co_u32 v1, vcc_lo, v1, v33
	s_delay_alu instid0(VALU_DEP_1)
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo
	v_dual_mov_b32 v8, v16 :: v_dual_mov_b32 v9, v16
	s_clause 0x1
	global_load_b64 v[28:29], v[1:2], off
	global_load_b64 v[30:31], v[1:2], off offset:16
	v_dual_mov_b32 v26, v24 :: v_dual_lshlrev_b32 v1, 10, v3
	v_dual_mov_b32 v10, v16 :: v_dual_mov_b32 v11, v16
	v_dual_mov_b32 v12, v16 :: v_dual_mov_b32 v13, v16
	s_delay_alu instid0(VALU_DEP_3)
	v_or3_b32 v35, v1, s4, v33
	v_dual_mov_b32 v14, v16 :: v_dual_mov_b32 v15, v16
	v_dual_mov_b32 v0, v16 :: v_dual_mov_b32 v1, v16
	v_dual_mov_b32 v2, v16 :: v_dual_mov_b32 v3, v16
	v_dual_mov_b32 v4, v16 :: v_dual_mov_b32 v5, v16
	v_dual_mov_b32 v6, v16 :: v_dual_mov_b32 v7, v16
	s_mov_b32 s5, -16
	s_mov_b32 s6, 0x3fb84000
.LBB9_5:                                ; =>This Inner Loop Header: Depth=1
	v_add_co_u32 v36, s7, s0, v34
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v37, null, s1, 0, s7
	v_add_co_u32 v38, s7, s0, v35
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v39, null, s1, 0, s7
	s_clause 0x11
	global_load_u8 v50, v[36:37], off offset:1967104
	global_load_u8 v51, v[36:37], off offset:1968128
	global_load_u8 v52, v[36:37], off offset:1969152
	global_load_u8 v53, v[36:37], off offset:1971200
	global_load_u8 v54, v[36:37], off offset:1972224
	global_load_u8 v55, v[36:37], off offset:1973248
	global_load_b64 v[44:45], v[38:39], off offset:983040
	global_load_b64 v[46:47], v[38:39], off offset:983056
	global_load_u8 v56, v[36:37], off offset:1966080
	global_load_u8 v57, v[36:37], off offset:1966096
	global_load_u8 v58, v[36:37], off offset:1970192
	global_load_u8 v59, v[36:37], off offset:1970176
	global_load_u8 v60, v[36:37], off offset:1969168
	global_load_u8 v61, v[36:37], off offset:1968144
	global_load_u8 v62, v[36:37], off offset:1967120
	global_load_u8 v63, v[36:37], off offset:1973264
	global_load_u8 v64, v[36:37], off offset:1972240
	global_load_u8 v65, v[36:37], off offset:1971216
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v49, 0
	s_wait_alu 0xfffe
	s_add_co_i32 s5, s5, 16
	s_add_nc_u64 s[0:1], s[0:1], 0x4000
	s_wait_alu 0xfffe
	s_cmp_lt_u32 s5, 0x3b0
	s_wait_loadcnt 0xb
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[44:45], v[28:29], 0
	s_wait_loadcnt 0x9
	v_lshl_or_b32 v44, v50, 8, v56
	s_delay_alu instid0(VALU_DEP_2)
	v_wmma_f32_16x16x16_fp8_fp8 v[36:43], v[46:47], v[30:31], v[36:43]
	v_lshlrev_b32_e32 v45, 16, v51
	v_lshlrev_b32_e32 v50, 24, v52
	s_wait_loadcnt 0x6
	v_lshl_or_b32 v51, v53, 8, v59
	v_dual_mul_f32 v38, 0x3db76000, v38 :: v_dual_lshlrev_b32 v53, 24, v55
	s_wait_loadcnt 0x4
	v_dual_mul_f32 v40, 0x3db76000, v40 :: v_dual_lshlrev_b32 v55, 16, v61
	v_dual_mul_f32 v41, 0x3db76000, v41 :: v_dual_lshlrev_b32 v56, 24, v60
	v_dual_mul_f32 v36, 0x3db76000, v36 :: v_dual_mul_f32 v37, 0x3db76000, v37
	v_dual_mul_f32 v39, 0x3db76000, v39 :: v_dual_lshlrev_b32 v52, 16, v54
	s_wait_loadcnt 0x3
	v_lshl_or_b32 v54, v62, 8, v57
	s_wait_loadcnt 0x0
	v_lshl_or_b32 v57, v65, 8, v58
	v_dual_mul_f32 v43, 0x3db76000, v43 :: v_dual_lshlrev_b32 v58, 16, v64
	v_dual_mul_f32 v42, 0x3db76000, v42 :: v_dual_lshlrev_b32 v59, 24, v63
	v_dual_add_f32 v36, 0x3fdac000, v36 :: v_dual_add_f32 v37, 0x3fdac000, v37
	v_dual_add_f32 v38, 0x3fdac000, v38 :: v_dual_add_f32 v39, 0x3fdac000, v39
	v_dual_add_f32 v40, 0x3fdac000, v40 :: v_dual_add_f32 v41, 0x3fdac000, v41
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_dual_add_f32 v42, 0x3fdac000, v42 :: v_dual_add_f32 v43, 0x3fdac000, v43
	v_med3_num_f32 v36, v36, s6, 0x3ffd2000
	v_med3_num_f32 v37, v37, s6, 0x3ffd2000
	v_med3_num_f32 v38, v38, s6, 0x3ffd2000
	v_med3_num_f32 v40, v40, s6, 0x3ffd2000
	v_med3_num_f32 v41, v41, s6, 0x3ffd2000
	v_med3_num_f32 v39, v39, s6, 0x3ffd2000
	v_med3_num_f32 v42, v42, s6, 0x3ffd2000
	v_med3_num_f32 v43, v43, s6, 0x3ffd2000
	v_lshrrev_b32_e32 v36, 9, v36
	v_lshrrev_b32_e32 v37, 9, v37
	v_lshrrev_b32_e32 v38, 9, v38
	v_lshrrev_b32_e32 v40, 9, v40
	v_lshrrev_b32_e32 v41, 9, v41
	v_lshrrev_b32_e32 v39, 9, v39
	v_lshrrev_b32_e32 v42, 9, v42
	v_lshrrev_b32_e32 v43, 9, v43
	v_and_b32_e32 v36, -16, v36
	v_and_b32_e32 v37, -16, v37
	v_and_b32_e32 v38, -16, v38
	v_and_b32_e32 v40, -16, v40
	v_and_b32_e32 v41, -16, v41
	v_or3_b32 v44, v44, v45, v50
	v_and_b32_e32 v39, -16, v39
	v_and_b32_e32 v42, -16, v42
	v_and_b32_e32 v43, -16, v43
	v_add_nc_u16 v36, 0x4000, v36
	v_add_nc_u16 v50, 0x4000, v37
	v_add_nc_u16 v37, 0x4000, v38
	v_add_nc_u16 v38, 0x4000, v40
	v_add_nc_u16 v40, 0x4000, v41
	v_or3_b32 v45, v51, v52, v53
	v_or3_b32 v46, v54, v55, v56
	v_add_nc_u16 v51, 0x4000, v39
	v_add_nc_u16 v39, 0x4000, v42
	v_add_nc_u16 v41, 0x4000, v43
	v_cvt_f32_f16_e32 v42, v36
	v_cvt_f32_f16_e32 v43, v50
	v_cvt_f32_f16_e32 v54, v38
	v_cvt_f32_f16_e32 v55, v40
	v_or3_b32 v47, v57, v58, v59
	v_cvt_f32_f16_e32 v52, v37
	v_cvt_f32_f16_e32 v53, v51
	v_cvt_f32_f16_e32 v56, v39
	v_cvt_f32_f16_e32 v57, v41
	v_cvt_pk_fp8_f32 v48, v42, v43
	v_cvt_pk_fp8_f32 v49, v54, v55
	v_perm_b32 v39, v41, v39, 0x5040100
	v_perm_b32 v38, v40, v38, 0x5040100
	v_perm_b32 v37, v51, v37, 0x5040100
	v_perm_b32 v36, v50, v36, 0x5040100
	v_cvt_pk_fp8_f32 v48, v52, v53 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v49, v56, v57 op_sel:[0,0,1]
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)
	v_wmma_f32_16x16x16_f16 v[16:23], v[24:27], v[36:39], v[16:23]
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[44:45], v[48:49], v[8:15]
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[46:47], v[48:49], v[0:7]
	s_cbranch_scc1 .LBB9_5
; %bb.6:
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(TRANS32_DEP_1)
	v_rcp_f32_e32 v17, v16
	s_mov_b32 s0, 0xc3e00000
	v_dual_mov_b32 v19, 0 :: v_dual_mov_b32 v20, 0
	v_dual_mov_b32 v21, 0 :: v_dual_mov_b32 v22, 0
	v_fma_f32 v18, -v16, v17, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v17, v17, v18 :: v_dual_mov_b32 v18, 0
	v_fma_f32 v16, -v16, v17, 1.0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_dual_fmac_f32 v17, v17, v16 :: v_dual_mov_b32 v16, 0
	v_dual_mov_b32 v23, 0 :: v_dual_mul_f32 v8, v8, v17
	v_mul_f32_e32 v11, v11, v17
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v11, v11, v11
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v11, v11
	;;#ASMEND
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_dual_mul_f32 v10, v10, v17 :: v_dual_add_f32 v11, 0, v11
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v10, v10, v10
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v10, v10
	;;#ASMEND
	v_add_f32_e32 v10, 0, v10
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v8, v8, v8
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v8, v8
	;;#ASMEND
	v_dual_mul_f32 v9, v9, v17 :: v_dual_add_f32 v8, 0, v8
	s_wait_alu 0xfffe
	v_med3_num_f32 v10, v10, s0, 0x43e00000
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v9, v9, v9
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v9, v9
	;;#ASMEND
	v_mul_f32_e32 v13, v13, v17
	v_med3_num_f32 v8, v8, s0, 0x43e00000
	v_cvt_pk_fp8_f32 v16, v10, 0
	v_add_f32_e32 v9, 0, v9
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v13, v13, v13
	;;#ASMEND
	v_mul_f32_e32 v12, v12, v17
	;;#ASMSTART
	v_cvt_f32_f16 v13, v13
	;;#ASMEND
	v_cvt_pk_fp8_f32 v19, v8, 0
	v_dual_add_f32 v8, 0, v13 :: v_dual_and_b32 v13, 0xff, v16
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v12, v12, v12
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v12, v12
	;;#ASMEND
	v_med3_num_f32 v9, v9, s0, 0x43e00000
	v_med3_num_f32 v11, v11, s0, 0x43e00000
	v_dual_add_f32 v12, 0, v12 :: v_dual_mul_f32 v15, v15, v17
	v_and_b32_e32 v10, 0xff, v19
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_cvt_pk_fp8_f32 v20, v9, 0
	v_cvt_pk_fp8_f32 v21, v11, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_med3_num_f32 v12, v12, s0, 0x43e00000
	v_mul_f32_e32 v0, v0, v17
	v_mul_f32_e32 v2, v2, v17
	v_lshlrev_b16 v9, 8, v20
	v_lshlrev_b16 v11, 8, v21
	v_cvt_pk_fp8_f32 v22, v12, 0
	v_mul_f32_e32 v4, v4, v17
	v_mul_f32_e32 v1, v1, v17
	v_or_b32_e32 v9, v10, v9
	v_or_b32_e32 v10, v13, v11
	v_and_b32_e32 v13, 0xff, v22
	v_med3_num_f32 v8, v8, s0, 0x43e00000
	v_mul_f32_e32 v14, v14, v17
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v1, v1, v1
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v1, v1
	;;#ASMEND
	v_add_f32_e32 v1, 0, v1
	v_cvt_pk_fp8_f32 v23, v8, 0
	v_and_b32_e32 v8, 0xffff, v9
	v_lshlrev_b32_e32 v9, 16, v10
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v14, v14, v14
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v14, v14
	;;#ASMEND
	v_add_f32_e32 v14, 0, v14
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v10, v15, v15
	;;#ASMEND
	v_mov_b32_e32 v15, 0
	;;#ASMSTART
	v_cvt_f32_f16 v10, v10
	;;#ASMEND
	v_add_f32_e32 v10, 0, v10
	v_med3_num_f32 v11, v14, s0, 0x43e00000
	v_mov_b32_e32 v14, 0
	v_lshlrev_b16 v12, 8, v23
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_med3_num_f32 v10, v10, s0, 0x43e00000
	v_cvt_pk_fp8_f32 v14, v11, 0
	v_mov_b32_e32 v11, 0
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v0, v0, v0
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v0, v0
	;;#ASMEND
	v_add_f32_e32 v0, 0, v0
	v_or_b32_e32 v12, v13, v12
	v_and_b32_e32 v13, 0xff, v14
	v_cvt_pk_fp8_f32 v15, v10, 0
	v_mov_b32_e32 v14, 0
	v_med3_num_f32 v0, v0, s0, 0x43e00000
	v_and_b32_e32 v10, 0xffff, v12
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)
	v_lshlrev_b16 v12, 8, v15
	v_mov_b32_e32 v15, 0
	v_cvt_pk_fp8_f32 v11, v0, 0
	v_med3_num_f32 v0, v1, s0, 0x43e00000
	v_mul_f32_e32 v1, v3, v17
	v_mov_b32_e32 v3, 0
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v2, v2, v2
	;;#ASMEND
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v1, v1, v1
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v2, v2
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v1, v1
	;;#ASMEND
	v_dual_add_f32 v2, 0, v2 :: v_dual_add_f32 v1, 0, v1
	v_cvt_pk_fp8_f32 v3, v0, 0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)
	v_med3_num_f32 v2, v2, s0, 0x43e00000
	v_med3_num_f32 v0, v1, s0, 0x43e00000
	v_mov_b32_e32 v1, 0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_lshlrev_b16 v3, 8, v3
	v_cvt_pk_fp8_f32 v14, v2, 0
	s_delay_alu instid0(VALU_DEP_3)
	v_cvt_pk_fp8_f32 v1, v0, 0
	v_mul_f32_e32 v0, v5, v17
	v_mul_f32_e32 v5, v6, v17
	v_dual_mul_f32 v6, v7, v17 :: v_dual_mov_b32 v7, 0
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v2, v4, v4
	;;#ASMEND
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v4, 0xff, v11
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v0, v0, v0
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v0, v0
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v2, v2
	;;#ASMEND
	v_add_f32_e32 v0, 0, v0
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v5, v5, v5
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v5, v5
	;;#ASMEND
	v_dual_add_f32 v2, 0, v2 :: v_dual_add_f32 v5, 0, v5
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_med3_num_f32 v0, v0, s0, 0x43e00000
	v_lshlrev_b16 v1, 8, v1
	v_or_b32_e32 v3, v4, v3
	v_med3_num_f32 v2, v2, s0, 0x43e00000
	v_med3_num_f32 v5, v5, s0, 0x43e00000
	v_cvt_pk_fp8_f32 v11, v0, 0
	v_and_b32_e32 v0, 0xff, v14
	v_and_b32_e32 v3, 0xffff, v3
	v_cvt_pk_fp8_f32 v7, v2, 0
	v_cvt_pk_fp8_f32 v15, v5, 0
	v_lshlrev_b16 v2, 8, v11
	v_or_b32_e32 v11, v13, v12
	v_or_b32_e32 v0, v0, v1
	v_and_b32_e32 v5, 0xff, v7
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v6, v6, v6
	;;#ASMEND
	;;#ASMSTART
	v_cvt_f32_f16 v6, v6
	;;#ASMEND
	v_dual_add_f32 v6, 0, v6 :: v_dual_and_b32 v7, 0xff, v15
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_or_b32_e32 v1, v5, v2
	v_lshlrev_b32_e32 v4, 16, v11
	v_lshlrev_b32_e32 v5, 16, v0
	v_med3_num_f32 v6, v6, s0, 0x43e00000
	v_or3_b32 v11, v33, s4, v32
	v_or_b32_e32 v0, v8, v9
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_cvt_pk_fp8_f32 v18, v6, 0
	v_lshlrev_b16 v6, 8, v18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)
	v_or_b32_e32 v2, v7, v6
	v_and_b32_e32 v6, 0xffff, v1
	v_or_b32_e32 v1, v10, v4
	v_lshlrev_b32_e32 v7, 16, v2
	v_or_b32_e32 v2, v3, v5
	s_delay_alu instid0(VALU_DEP_2)
	v_or_b32_e32 v3, v6, v7
	s_clause 0x1
	global_store_b64 v11, v[0:1], s[2:3]
	global_store_b64 v11, v[2:3], s[2:3] offset:16
.LBB9_7:
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel vit_attention_fused_960_bytein_bout
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 32
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 66
		.amdhsa_next_free_sgpr 8
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 18
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
