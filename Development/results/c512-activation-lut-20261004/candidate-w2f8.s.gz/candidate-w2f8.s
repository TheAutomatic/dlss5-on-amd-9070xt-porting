split_ffn_one_w2f8:                     ; @split_ffn_one_w2f8
; %bb.0:
	s_load_b32 s2, s[0:1], 0x18
	v_lshrrev_b32_e32 v1, 1, v0
	s_lshl_b32 s3, ttmp9, 2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)
	v_and_b32_e32 v1, 16, v1
	v_and_or_b32 v41, 0xffffffe0, s3, v1
	s_wait_kmcnt 0x0
	s_delay_alu instid0(VALU_DEP_1)
	v_cmp_gt_u32_e32 vcc_lo, s2, v41
	s_and_saveexec_b32 s2, vcc_lo
	s_cbranch_execz .LBB79_6
; %bb.1:
	v_bfe_u32 v42, v0, 4, 1
	v_mov_b32_e32 v2, 0
	s_clause 0x1
	s_load_b128 s[36:39], s[0:1], 0x0
	s_load_b64 s[34:35], s[0:1], 0x10
	s_and_b32 s31, ttmp9, 7
	v_lshlrev_b32_e32 v43, 3, v42
	v_dual_mov_b32 v3, v2 :: v_dual_and_b32 v40, 15, v0
	s_lshl_b32 s33, s31, 6
	s_lshl_b32 s0, s31, 15
	v_mov_b32_e32 v4, v2
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)
	v_add_lshl_u32 v1, v41, v40, 9
	v_or_b32_e32 v0, s33, v40
	v_lshlrev_b32_e32 v35, 9, v40
	v_dual_mov_b32 v5, v2 :: v_dual_mov_b32 v6, v2
	v_lshlrev_b64_e32 v[33:34], 2, v[1:2]
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)
	v_lshl_or_b32 v0, v0, 9, v43
	v_or3_b32 v36, s0, v35, v43
	v_dual_mov_b32 v7, v2 :: v_dual_mov_b32 v8, v2
	v_dual_mov_b32 v9, v2 :: v_dual_mov_b32 v10, v2
	v_lshl_or_b32 v33, v42, 5, v33
	v_or_b32_e32 v35, 0x6000, v0
	v_or_b32_e32 v37, 0x4000, v0
	s_wait_kmcnt 0x0
	v_add_co_u32 v36, s2, s38, v36
	v_add_co_u32 v33, vcc_lo, v33, s36
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)
	v_add_co_ci_u32_e64 v34, null, s37, v34, vcc_lo
	v_add_co_u32 v0, s0, s38, v35
	v_add_co_u32 v35, s1, s38, v37
	v_add_co_u32 v33, vcc_lo, 0xdc, v33
	v_dual_mov_b32 v11, v2 :: v_dual_mov_b32 v12, v2
	v_dual_mov_b32 v13, v2 :: v_dual_mov_b32 v14, v2
	v_dual_mov_b32 v15, v2 :: v_dual_mov_b32 v16, v2
	v_dual_mov_b32 v17, v2 :: v_dual_mov_b32 v18, v2
	v_dual_mov_b32 v19, v2 :: v_dual_mov_b32 v20, v2
	v_dual_mov_b32 v21, v2 :: v_dual_mov_b32 v22, v2
	v_dual_mov_b32 v23, v2 :: v_dual_mov_b32 v24, v2
	v_dual_mov_b32 v25, v2 :: v_dual_mov_b32 v26, v2
	v_dual_mov_b32 v27, v2 :: v_dual_mov_b32 v28, v2
	v_dual_mov_b32 v29, v2 :: v_dual_mov_b32 v30, v2
	v_dual_mov_b32 v31, v2 :: v_dual_mov_b32 v32, v2
	v_mov_b32_e32 v1, v2
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v37, null, s39, 0, s0
	v_add_co_ci_u32_e64 v38, null, s39, 0, s1
	v_add_co_ci_u32_e64 v39, null, s39, 0, s2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo
	s_mov_b64 s[2:3], 0
.LBB79_2:                               ; =>This Inner Loop Header: Depth=1
	s_clause 0x7
	global_load_b128 v[44:47], v[33:34], off offset:-204
	global_load_b128 v[48:51], v[33:34], off offset:-220
	global_load_b128 v[52:55], v[33:34], off offset:-140
	global_load_b128 v[56:59], v[33:34], off offset:-156
	global_load_b128 v[60:63], v[33:34], off offset:-76
	global_load_b128 v[64:67], v[33:34], off offset:-92
	global_load_b128 v[68:71], v[33:34], off offset:-12
	global_load_b128 v[72:75], v[33:34], off offset:-28
	s_wait_alu 0xfffe
	v_add_co_u32 v76, vcc_lo, v36, s2
	v_add_co_u32 v78, s0, v35, s2
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v77, null, s3, v39, vcc_lo
	v_add_co_u32 v80, s1, v0, s2
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v79, null, s3, v38, s0
	v_add_co_ci_u32_e64 v81, null, s3, v37, s1
	s_clause 0xf
	global_load_b64 v[82:83], v[76:77], off
	global_load_b64 v[84:85], v[76:77], off offset:8192
	global_load_b64 v[86:87], v[78:79], off
	global_load_b64 v[88:89], v[80:81], off
	global_load_b64 v[90:91], v[76:77], off offset:16
	global_load_b64 v[92:93], v[76:77], off offset:8208
	global_load_b64 v[94:95], v[78:79], off offset:16
	global_load_b64 v[96:97], v[80:81], off offset:16
	global_load_b64 v[98:99], v[76:77], off offset:32
	global_load_b64 v[100:101], v[76:77], off offset:8224
	global_load_b64 v[102:103], v[78:79], off offset:32
	global_load_b64 v[104:105], v[80:81], off offset:32
	global_load_b64 v[106:107], v[76:77], off offset:48
	global_load_b64 v[76:77], v[76:77], off offset:8240
	global_load_b64 v[78:79], v[78:79], off offset:48
	global_load_b64 v[80:81], v[80:81], off offset:48
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v109, 0
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v111, 0
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v113, 0
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v115, 0
	v_add_co_u32 v33, vcc_lo, 0x100, v33
	s_add_nc_u64 s[2:3], s[2:3], 64
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v34, null, 0, v34, vcc_lo
	s_wait_alu 0xfffe
	s_add_co_i32 s0, s2, -16
	s_wait_alu 0xfffe
	s_cmp_lt_u32 s0, 0x1f0
	s_wait_loadcnt 0x15
	v_cvt_pk_fp8_f32 v111, v52, v53
	s_wait_loadcnt 0x14
	v_cvt_pk_fp8_f32 v110, v56, v57
	s_wait_loadcnt 0x13
	v_cvt_pk_fp8_f32 v113, v60, v61
	v_cvt_pk_fp8_f32 v109, v44, v45
	v_cvt_pk_fp8_f32 v108, v48, v49
	s_wait_loadcnt 0x12
	v_cvt_pk_fp8_f32 v112, v64, v65
	v_cvt_pk_fp8_f32 v110, v58, v59 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v111, v54, v55 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v109, v46, v47 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v108, v50, v51 op_sel:[0,0,1]
	s_wait_loadcnt 0x10
	v_cvt_pk_fp8_f32 v114, v72, v73
	v_cvt_pk_fp8_f32 v115, v68, v69
	v_cvt_pk_fp8_f32 v112, v66, v67 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v113, v62, v63 op_sel:[0,0,1]
	s_wait_loadcnt 0xf
	v_wmma_f32_16x16x16_fp8_fp8 v[25:32], v[82:83], v[108:109], v[25:32]
	s_wait_loadcnt 0xe
	v_wmma_f32_16x16x16_fp8_fp8 v[17:24], v[84:85], v[108:109], v[17:24]
	s_wait_loadcnt 0xd
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[86:87], v[108:109], v[9:16]
	s_wait_loadcnt 0xc
	v_wmma_f32_16x16x16_fp8_fp8 v[1:8], v[88:89], v[108:109], v[1:8]
	v_cvt_pk_fp8_f32 v114, v74, v75 op_sel:[0,0,1]
	s_wait_loadcnt 0xb
	v_wmma_f32_16x16x16_fp8_fp8 v[25:32], v[90:91], v[110:111], v[25:32]
	s_wait_loadcnt 0xa
	v_wmma_f32_16x16x16_fp8_fp8 v[17:24], v[92:93], v[110:111], v[17:24]
	s_wait_loadcnt 0x9
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[94:95], v[110:111], v[9:16]
	s_wait_loadcnt 0x8
	v_wmma_f32_16x16x16_fp8_fp8 v[1:8], v[96:97], v[110:111], v[1:8]
	v_cvt_pk_fp8_f32 v115, v70, v71 op_sel:[0,0,1]
	s_wait_loadcnt 0x7
	v_wmma_f32_16x16x16_fp8_fp8 v[25:32], v[98:99], v[112:113], v[25:32]
	s_wait_loadcnt 0x6
	v_wmma_f32_16x16x16_fp8_fp8 v[17:24], v[100:101], v[112:113], v[17:24]
	s_wait_loadcnt 0x5
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[102:103], v[112:113], v[9:16]
	s_wait_loadcnt 0x4
	v_wmma_f32_16x16x16_fp8_fp8 v[1:8], v[104:105], v[112:113], v[1:8]
	s_wait_loadcnt 0x3
	v_wmma_f32_16x16x16_fp8_fp8 v[25:32], v[106:107], v[114:115], v[25:32]
	s_wait_loadcnt 0x2
	v_wmma_f32_16x16x16_fp8_fp8 v[17:24], v[76:77], v[114:115], v[17:24]
	s_wait_loadcnt 0x1
	v_wmma_f32_16x16x16_fp8_fp8 v[9:16], v[78:79], v[114:115], v[9:16]
	s_wait_loadcnt 0x0
	v_wmma_f32_16x16x16_fp8_fp8 v[1:8], v[80:81], v[114:115], v[1:8]
	s_cbranch_scc1 .LBB79_2
; %bb.3:
	v_dual_mov_b32 v0, 0 :: v_dual_and_b32 v25, 0xffffe000, v25
	v_dual_mov_b32 v47, 0 :: v_dual_and_b32 v26, 0xffffe000, v26
	v_dual_mov_b32 v50, 0 :: v_dual_and_b32 v29, 0xffffe000, v29
	v_dual_mov_b32 v51, 0 :: v_dual_and_b32 v30, 0xffffe000, v30
	v_dual_mov_b32 v53, 0 :: v_dual_and_b32 v44, 0xffffe000, v32
	v_dual_mov_b32 v32, 0 :: v_dual_and_b32 v17, 0xffffe000, v17
	v_dual_mov_b32 v55, 0 :: v_dual_and_b32 v18, 0xffffe000, v18
	v_dual_mov_b32 v58, 0 :: v_dual_and_b32 v21, 0xffffe000, v21
	v_dual_mov_b32 v59, 0 :: v_dual_and_b32 v22, 0xffffe000, v22
	v_dual_mov_b32 v34, 0 :: v_dual_and_b32 v9, 0xffffe000, v9
	v_dual_mov_b32 v63, 0 :: v_dual_and_b32 v10, 0xffffe000, v10
	v_dual_mov_b32 v66, 0 :: v_dual_and_b32 v13, 0xffffe000, v13
	v_dual_mov_b32 v67, 0 :: v_dual_and_b32 v14, 0xffffe000, v14
	v_dual_mov_b32 v36, 0 :: v_dual_and_b32 v1, 0xffffe000, v1
	v_dual_mov_b32 v71, 0 :: v_dual_and_b32 v2, 0xffffe000, v2
	v_dual_mov_b32 v74, 0 :: v_dual_and_b32 v5, 0xffffe000, v5
	v_dual_mov_b32 v75, 0 :: v_dual_and_b32 v6, 0xffffe000, v6
	v_dual_mov_b32 v48, 0 :: v_dual_and_b32 v27, 0xffffe000, v27
	v_dual_mov_b32 v49, 0 :: v_dual_and_b32 v28, 0xffffe000, v28
	v_dual_mov_b32 v52, 0 :: v_dual_and_b32 v31, 0xffffe000, v31
	v_dual_mov_b32 v56, 0 :: v_dual_and_b32 v19, 0xffffe000, v19
	v_dual_mov_b32 v57, 0 :: v_dual_and_b32 v20, 0xffffe000, v20
	v_dual_mov_b32 v60, 0 :: v_dual_and_b32 v23, 0xffffe000, v23
	v_dual_mov_b32 v61, 0 :: v_dual_and_b32 v24, 0xffffe000, v24
	v_dual_mov_b32 v64, 0 :: v_dual_and_b32 v11, 0xffffe000, v11
	v_dual_mov_b32 v65, 0 :: v_dual_and_b32 v12, 0xffffe000, v12
	v_dual_mov_b32 v68, 0 :: v_dual_and_b32 v15, 0xffffe000, v15
	v_dual_mov_b32 v69, 0 :: v_dual_and_b32 v16, 0xffffe000, v16
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v3, 0xffffe000, v3
	v_dual_mov_b32 v73, 0 :: v_dual_and_b32 v4, 0xffffe000, v4
	v_dual_mov_b32 v76, 0 :: v_dual_and_b32 v7, 0xffffe000, v7
	v_dual_mov_b32 v77, 0 :: v_dual_and_b32 v8, 0xffffe000, v8
	v_dual_max_num_f32 v46, v25, v25 :: v_dual_max_num_f32 v79, v26, v26
	v_dual_max_num_f32 v82, v29, v29 :: v_dual_max_num_f32 v83, v30, v30
	v_dual_max_num_f32 v86, v17, v17 :: v_dual_max_num_f32 v87, v18, v18
	v_dual_max_num_f32 v90, v21, v21 :: v_dual_max_num_f32 v91, v22, v22
	v_dual_max_num_f32 v94, v9, v9 :: v_dual_max_num_f32 v95, v10, v10
	v_dual_max_num_f32 v98, v13, v13 :: v_dual_max_num_f32 v99, v14, v14
	v_dual_max_num_f32 v102, v1, v1 :: v_dual_max_num_f32 v103, v2, v2
	v_dual_max_num_f32 v106, v5, v5 :: v_dual_max_num_f32 v107, v6, v6
	s_mov_b32 s36, 0xc3e00000
	v_dual_max_num_f32 v80, v27, v27 :: v_dual_max_num_f32 v81, v28, v28
	v_dual_max_num_f32 v84, v31, v31 :: v_dual_max_num_f32 v85, v44, v44
	v_dual_max_num_f32 v88, v19, v19 :: v_dual_max_num_f32 v89, v20, v20
	v_dual_max_num_f32 v92, v23, v23 :: v_dual_max_num_f32 v93, v24, v24
	v_dual_max_num_f32 v96, v11, v11 :: v_dual_max_num_f32 v97, v12, v12
	v_dual_max_num_f32 v100, v15, v15 :: v_dual_max_num_f32 v101, v16, v16
	v_dual_max_num_f32 v104, v3, v3 :: v_dual_max_num_f32 v105, v4, v4
	v_dual_max_num_f32 v108, v7, v7 :: v_dual_max_num_f32 v109, v8, v8
	s_wait_alu 0xfffe
	v_med3_num_f32 v110, v46, s36, 0x43e00000
	v_med3_num_f32 v79, v79, s36, 0x43e00000
	v_med3_num_f32 v82, v82, s36, 0x43e00000
	v_med3_num_f32 v83, v83, s36, 0x43e00000
	v_med3_num_f32 v86, v86, s36, 0x43e00000
	v_med3_num_f32 v87, v87, s36, 0x43e00000
	v_med3_num_f32 v90, v90, s36, 0x43e00000
	v_med3_num_f32 v91, v91, s36, 0x43e00000
	v_med3_num_f32 v94, v94, s36, 0x43e00000
	v_med3_num_f32 v95, v95, s36, 0x43e00000
	v_med3_num_f32 v98, v98, s36, 0x43e00000
	v_med3_num_f32 v99, v99, s36, 0x43e00000
	v_med3_num_f32 v102, v102, s36, 0x43e00000
	v_med3_num_f32 v103, v103, s36, 0x43e00000
	v_med3_num_f32 v106, v106, s36, 0x43e00000
	v_med3_num_f32 v107, v107, s36, 0x43e00000
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v33, 0
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v35, 0
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v37, 0
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v39, 0
	v_med3_num_f32 v80, v80, s36, 0x43e00000
	v_med3_num_f32 v81, v81, s36, 0x43e00000
	v_med3_num_f32 v84, v84, s36, 0x43e00000
	v_med3_num_f32 v85, v85, s36, 0x43e00000
	v_med3_num_f32 v88, v88, s36, 0x43e00000
	v_med3_num_f32 v89, v89, s36, 0x43e00000
	v_med3_num_f32 v92, v92, s36, 0x43e00000
	v_med3_num_f32 v93, v93, s36, 0x43e00000
	v_med3_num_f32 v96, v96, s36, 0x43e00000
	v_med3_num_f32 v97, v97, s36, 0x43e00000
	v_med3_num_f32 v100, v100, s36, 0x43e00000
	v_med3_num_f32 v101, v101, s36, 0x43e00000
	v_med3_num_f32 v104, v104, s36, 0x43e00000
	v_med3_num_f32 v105, v105, s36, 0x43e00000
	v_med3_num_f32 v108, v108, s36, 0x43e00000
	v_med3_num_f32 v109, v109, s36, 0x43e00000
	v_cvt_pk_fp8_f32 v47, v110, 0
	v_cvt_pk_fp8_f32 v48, v79, 0
	v_cvt_pk_fp8_f32 v51, v82, 0
	v_cvt_pk_fp8_f32 v52, v83, 0
	v_cvt_pk_fp8_f32 v55, v86, 0
	v_cvt_pk_fp8_f32 v56, v87, 0
	v_cvt_pk_fp8_f32 v59, v90, 0
	v_cvt_pk_fp8_f32 v60, v91, 0
	v_cvt_pk_fp8_f32 v63, v94, 0
	v_cvt_pk_fp8_f32 v64, v95, 0
	v_cvt_pk_fp8_f32 v67, v98, 0
	v_cvt_pk_fp8_f32 v68, v99, 0
	v_cvt_pk_fp8_f32 v71, v102, 0
	v_cvt_pk_fp8_f32 v72, v103, 0
	v_cvt_pk_fp8_f32 v75, v106, 0
	v_cvt_pk_fp8_f32 v76, v107, 0
	v_cmp_neq_f32_e32 vcc_lo, 0, v25
	v_cmp_neq_f32_e64 s0, 0, v26
	v_cmp_neq_f32_e64 s3, 0, v29
	v_cmp_neq_f32_e64 s4, 0, v30
	v_cmp_neq_f32_e64 s7, 0, v17
	v_cmp_neq_f32_e64 s8, 0, v18
	v_cmp_neq_f32_e64 s11, 0, v21
	v_cmp_neq_f32_e64 s12, 0, v22
	v_cmp_neq_f32_e64 s15, 0, v9
	v_cmp_neq_f32_e64 s16, 0, v10
	v_cmp_neq_f32_e64 s19, 0, v13
	v_cmp_neq_f32_e64 s20, 0, v14
	v_cmp_neq_f32_e64 s23, 0, v1
	v_cmp_neq_f32_e64 s24, 0, v2
	v_cmp_neq_f32_e64 s27, 0, v5
	v_cmp_neq_f32_e64 s28, 0, v6
	v_cvt_pk_fp8_f32 v49, v80, 0
	v_cvt_pk_fp8_f32 v50, v81, 0
	v_cvt_pk_fp8_f32 v53, v84, 0
	v_cvt_pk_fp8_f32 v54, v85, 0
	v_cvt_pk_fp8_f32 v57, v88, 0
	v_cvt_pk_fp8_f32 v58, v89, 0
	v_cvt_pk_fp8_f32 v61, v92, 0
	v_cvt_pk_fp8_f32 v62, v93, 0
	v_cvt_pk_fp8_f32 v65, v96, 0
	v_cvt_pk_fp8_f32 v66, v97, 0
	v_cvt_pk_fp8_f32 v69, v100, 0
	v_cvt_pk_fp8_f32 v70, v101, 0
	v_cvt_pk_fp8_f32 v73, v104, 0
	v_cvt_pk_fp8_f32 v74, v105, 0
	v_cvt_pk_fp8_f32 v77, v108, 0
	v_cvt_pk_fp8_f32 v78, v109, 0
	v_cvt_f32_fp8_e32 v47, v47
	v_cvt_f32_fp8_e32 v48, v48
	v_cvt_f32_fp8_e32 v51, v51
	v_cvt_f32_fp8_e32 v52, v52
	v_cvt_f32_fp8_e32 v55, v55
	v_cvt_f32_fp8_e32 v56, v56
	v_cvt_f32_fp8_e32 v59, v59
	v_cvt_f32_fp8_e32 v60, v60
	v_cvt_f32_fp8_e32 v63, v63
	v_cvt_f32_fp8_e32 v64, v64
	v_cvt_f32_fp8_e32 v67, v67
	v_cvt_f32_fp8_e32 v68, v68
	v_cvt_f32_fp8_e32 v71, v71
	v_cvt_f32_fp8_e32 v72, v72
	v_cvt_f32_fp8_e32 v75, v75
	v_cvt_f32_fp8_e32 v76, v76
	v_dual_mov_b32 v38, 0 :: v_dual_lshlrev_b32 v45, 8, v40
	v_cmp_neq_f32_e64 s1, 0, v27
	v_cmp_neq_f32_e64 s2, 0, v28
	v_cmp_neq_f32_e64 s5, 0, v31
	v_cmp_neq_f32_e64 s6, 0, v44
	v_cmp_neq_f32_e64 s9, 0, v19
	v_cmp_neq_f32_e64 s10, 0, v20
	v_cmp_neq_f32_e64 s13, 0, v23
	v_cmp_neq_f32_e64 s14, 0, v24
	v_cmp_neq_f32_e64 s17, 0, v11
	v_cmp_neq_f32_e64 s18, 0, v12
	v_cmp_neq_f32_e64 s21, 0, v15
	v_cmp_neq_f32_e64 s22, 0, v16
	v_cmp_neq_f32_e64 s25, 0, v3
	v_cmp_neq_f32_e64 s26, 0, v4
	v_cmp_neq_f32_e64 s29, 0, v7
	v_cmp_neq_f32_e64 s30, 0, v8
	v_cvt_f32_fp8_e32 v49, v49
	v_cvt_f32_fp8_e32 v50, v50
	v_cvt_f32_fp8_e32 v53, v53
	v_cvt_f32_fp8_e32 v54, v54
	v_cvt_f32_fp8_e32 v57, v57
	v_cvt_f32_fp8_e32 v58, v58
	v_cvt_f32_fp8_e32 v61, v61
	v_cvt_f32_fp8_e32 v62, v62
	v_cvt_f32_fp8_e32 v65, v65
	v_cvt_f32_fp8_e32 v66, v66
	v_cvt_f32_fp8_e32 v69, v69
	v_cvt_f32_fp8_e32 v70, v70
	v_cvt_f32_fp8_e32 v73, v73
	v_cvt_f32_fp8_e32 v74, v74
	v_cvt_f32_fp8_e32 v77, v77
	v_cvt_f32_fp8_e32 v78, v78
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v47, 0, v47, vcc_lo
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v48, 0, v48, s0
	v_cndmask_b32_e64 v51, 0, v51, s3
	v_cndmask_b32_e64 v52, 0, v52, s4
	v_cndmask_b32_e64 v55, 0, v55, s7
	v_cndmask_b32_e64 v56, 0, v56, s8
	v_cndmask_b32_e64 v59, 0, v59, s11
	v_cndmask_b32_e64 v60, 0, v60, s12
	v_cndmask_b32_e64 v63, 0, v63, s15
	v_cndmask_b32_e64 v64, 0, v64, s16
	v_cndmask_b32_e64 v67, 0, v67, s19
	v_cndmask_b32_e64 v68, 0, v68, s20
	v_cndmask_b32_e64 v71, 0, v71, s23
	v_cndmask_b32_e64 v72, 0, v72, s24
	v_cndmask_b32_e64 v75, 0, v75, s27
	v_cndmask_b32_e64 v76, 0, v76, s28
	v_lshl_or_b32 v43, v40, 6, v43
	v_lshl_or_b32 v45, v42, 3, v45
	v_cndmask_b32_e64 v49, 0, v49, s1
	v_cndmask_b32_e64 v50, 0, v50, s2
	v_cndmask_b32_e64 v53, 0, v53, s5
	v_cndmask_b32_e64 v54, 0, v54, s6
	v_cndmask_b32_e64 v57, 0, v57, s9
	v_cndmask_b32_e64 v58, 0, v58, s10
	v_cndmask_b32_e64 v61, 0, v61, s13
	v_cndmask_b32_e64 v62, 0, v62, s14
	v_cndmask_b32_e64 v65, 0, v65, s17
	v_cndmask_b32_e64 v66, 0, v66, s18
	v_cndmask_b32_e64 v69, 0, v69, s21
	v_cndmask_b32_e64 v70, 0, v70, s22
	v_cndmask_b32_e64 v73, 0, v73, s25
	v_cndmask_b32_e64 v74, 0, v74, s26
	v_cndmask_b32_e64 v77, 0, v77, s29
	v_cndmask_b32_e64 v78, 0, v78, s30
	v_cvt_pk_fp8_f32 v32, v47, v48
	v_cvt_pk_fp8_f32 v33, v51, v52
	v_cvt_pk_fp8_f32 v34, v55, v56
	v_cvt_pk_fp8_f32 v35, v59, v60
	v_cvt_pk_fp8_f32 v36, v63, v64
	v_cvt_pk_fp8_f32 v37, v67, v68
	v_cvt_pk_fp8_f32 v38, v71, v72
	v_cvt_pk_fp8_f32 v39, v75, v76
	v_add_co_u32 v43, s37, s38, v43
	v_add_co_u32 v45, s36, s38, v45
	v_dual_mov_b32 v1, v0 :: v_dual_mov_b32 v2, v0
	v_dual_mov_b32 v3, v0 :: v_dual_mov_b32 v4, v0
	v_dual_mov_b32 v5, v0 :: v_dual_mov_b32 v6, v0
	v_dual_mov_b32 v7, v0 :: v_dual_mov_b32 v8, v0
	v_dual_mov_b32 v9, v0 :: v_dual_mov_b32 v10, v0
	v_dual_mov_b32 v11, v0 :: v_dual_mov_b32 v12, v0
	v_dual_mov_b32 v13, v0 :: v_dual_mov_b32 v14, v0
	v_dual_mov_b32 v15, v0 :: v_dual_mov_b32 v16, v0
	v_dual_mov_b32 v17, v0 :: v_dual_mov_b32 v18, v0
	v_dual_mov_b32 v19, v0 :: v_dual_mov_b32 v20, v0
	v_dual_mov_b32 v21, v0 :: v_dual_mov_b32 v22, v0
	v_dual_mov_b32 v23, v0 :: v_dual_mov_b32 v24, v0
	v_dual_mov_b32 v25, v0 :: v_dual_mov_b32 v26, v0
	v_dual_mov_b32 v27, v0 :: v_dual_mov_b32 v28, v0
	v_dual_mov_b32 v29, v0 :: v_dual_mov_b32 v30, v0
	v_mov_b32_e32 v31, v0
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v44, null, s39, 0, s37
	v_add_co_ci_u32_e64 v46, null, s39, 0, s36
	v_cvt_pk_fp8_f32 v32, v49, v50 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v33, v53, v54 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v34, v57, v58 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v35, v61, v62 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v36, v65, v66 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v37, v69, v70 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v38, v73, v74 op_sel:[0,0,1]
	v_cvt_pk_fp8_f32 v39, v77, v78 op_sel:[0,0,1]
	s_lshl_b32 s1, s31, 14
	s_mov_b32 s2, 16
	s_getpc_b64 s[4:5]
	s_wait_alu 0xfffe
	s_sext_i32_i16 s5, s5
	s_add_co_u32 s4, s4, c512_activation_table@rel32@lo+12
	s_wait_alu 0xfffe
	s_add_co_ci_u32 s5, s5, c512_activation_table@rel32@hi+24
.LBB79_4:                               ; =>This Inner Loop Header: Depth=1
	v_add_co_u32 v47, vcc_lo, v43, s1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v48, null, 0, v44, vcc_lo
	v_add_co_u32 v43, s0, 0x400, v43
	s_wait_alu 0xf1ff
	v_add_co_ci_u32_e64 v44, null, 0, v44, s0
	s_clause 0x3
	global_load_b64 v[55:56], v[47:48], off offset:1048576
	global_load_b64 v[57:58], v[47:48], off offset:1048592
	global_load_b64 v[59:60], v[47:48], off offset:1048608
	global_load_b64 v[61:62], v[47:48], off offset:1048624
	s_add_co_i32 s2, s2, -1
	s_wait_alu 0xfffe
	s_cmp_lg_u32 s2, 0
	s_wait_loadcnt 0x3
	v_wmma_f32_16x16x16_fp8_fp8 v[47:54], v[55:56], v[32:33], 0
	s_wait_loadcnt 0x2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_wmma_f32_16x16x16_fp8_fp8 v[47:54], v[57:58], v[34:35], v[47:54]
	s_wait_loadcnt 0x1
	v_wmma_f32_16x16x16_fp8_fp8 v[47:54], v[59:60], v[36:37], v[47:54]
	s_wait_loadcnt 0x0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)
	v_wmma_f32_16x16x16_fp8_fp8 v[47:54], v[61:62], v[38:39], v[47:54]
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v47, v47, v47
	;;#ASMEND
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v48, v48, v48
	;;#ASMEND
	v_and_b32_e32 v47, 0xffff, v47
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v49, v49, v49
	;;#ASMEND
	v_and_b32_e32 v48, 0xffff, v48
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v50, v50, v50
	;;#ASMEND
	v_and_b32_e32 v49, 0xffff, v49
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v51, v51, v51
	;;#ASMEND
	v_and_b32_e32 v50, 0xffff, v50
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v52, v52, v52
	;;#ASMEND
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v53, v53, v53
	;;#ASMEND
	;;#ASMSTART
	v_cvt_pkrtz_f16_f32 v54, v54, v54
	;;#ASMEND
	v_and_b32_e32 v51, 0xffff, v51
	v_and_b32_e32 v52, 0xffff, v52
	v_and_b32_e32 v53, 0xffff, v53
	v_and_b32_e32 v54, 0xffff, v54
	s_clause 0x7
	global_load_u8 v55, v47, s[4:5]
	global_load_u8 v56, v48, s[4:5]
	global_load_u8 v57, v49, s[4:5]
	global_load_u8 v58, v50, s[4:5]
	global_load_u8 v59, v51, s[4:5]
	global_load_u8 v60, v52, s[4:5]
	global_load_u8 v61, v53, s[4:5]
	global_load_u8 v62, v54, s[4:5]
	v_add_co_u32 v47, vcc_lo, v45, s1
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v48, null, 0, v46, vcc_lo
	s_clause 0x3
	global_load_b64 v[49:50], v[47:48], off offset:1572864
	global_load_b64 v[51:52], v[47:48], off offset:1576960
	global_load_b64 v[53:54], v[47:48], off offset:1581056
	global_load_b64 v[47:48], v[47:48], off offset:1585152
	v_add_co_u32 v45, vcc_lo, v45, 16
	s_wait_alu 0xfffd
	v_add_co_ci_u32_e64 v46, null, 0, v46, vcc_lo
	s_wait_loadcnt 0xa
	v_lshl_or_b32 v55, v56, 8, v55
	s_wait_loadcnt 0x9
	v_lshlrev_b32_e32 v56, 16, v57
	s_wait_loadcnt 0x8
	v_lshlrev_b32_e32 v57, 24, v58
	s_wait_loadcnt 0x6
	v_lshl_or_b32 v58, v60, 8, v59
	s_wait_loadcnt 0x5
	v_lshlrev_b32_e32 v59, 16, v61
	s_wait_loadcnt 0x4
	v_lshlrev_b32_e32 v60, 24, v62
	v_or3_b32 v55, v55, v56, v57
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)
	v_or3_b32 v56, v58, v59, v60
	s_wait_loadcnt 0x3
	v_wmma_f32_16x16x16_fp8_fp8 v[24:31], v[55:56], v[49:50], v[24:31]
	s_wait_loadcnt 0x2
	v_wmma_f32_16x16x16_fp8_fp8 v[16:23], v[55:56], v[51:52], v[16:23]
	s_wait_loadcnt 0x1
	v_wmma_f32_16x16x16_fp8_fp8 v[8:15], v[55:56], v[53:54], v[8:15]
	s_wait_loadcnt 0x0
	v_wmma_f32_16x16x16_fp8_fp8 v[0:7], v[55:56], v[47:48], v[0:7]
	s_cbranch_scc1 .LBB79_4
; %bb.5:
	v_dual_mov_b32 v36, 0 :: v_dual_and_b32 v35, 0xffffe000, v24
	s_or_b32 s0, s33, 32
	v_dual_mov_b32 v24, 0 :: v_dual_lshlrev_b32 v33, 8, v42
	s_wait_alu 0xfffe
	s_lshr_b32 s0, s0, 5
	v_lshlrev_b32_e32 v34, 9, v41
	v_dual_mov_b32 v32, 0 :: v_dual_and_b32 v37, 0xffffe000, v25
	v_dual_mov_b32 v38, 0 :: v_dual_and_b32 v39, 0xffffe000, v26
	v_dual_mov_b32 v42, 0 :: v_dual_and_b32 v43, 0xffffe000, v27
	v_dual_mov_b32 v44, 0 :: v_dual_and_b32 v45, 0xffffe000, v28
	v_dual_mov_b32 v46, 0 :: v_dual_and_b32 v47, 0xffffe000, v29
	v_dual_mov_b32 v48, 0 :: v_dual_and_b32 v49, 0xffffe000, v30
	v_dual_mov_b32 v50, 0 :: v_dual_and_b32 v31, 0xffffe000, v31
	v_dual_mov_b32 v55, 0 :: v_dual_and_b32 v16, 0xffffe000, v16
	v_dual_mov_b32 v54, 0 :: v_dual_and_b32 v17, 0xffffe000, v17
	v_dual_mov_b32 v59, 0 :: v_dual_and_b32 v18, 0xffffe000, v18
	v_dual_mov_b32 v58, 0 :: v_dual_and_b32 v19, 0xffffe000, v19
	v_dual_mov_b32 v63, 0 :: v_dual_and_b32 v20, 0xffffe000, v20
	v_dual_mov_b32 v62, 0 :: v_dual_and_b32 v21, 0xffffe000, v21
	v_dual_mov_b32 v67, 0 :: v_dual_and_b32 v22, 0xffffe000, v22
	v_dual_mov_b32 v66, 0 :: v_dual_and_b32 v23, 0xffffe000, v23
	v_dual_mov_b32 v71, 0 :: v_dual_and_b32 v8, 0xffffe000, v8
	v_dual_mov_b32 v70, 0 :: v_dual_and_b32 v9, 0xffffe000, v9
	v_dual_mov_b32 v75, 0 :: v_dual_and_b32 v10, 0xffffe000, v10
	v_dual_mov_b32 v74, 0 :: v_dual_and_b32 v11, 0xffffe000, v11
	v_dual_mov_b32 v79, 0 :: v_dual_and_b32 v12, 0xffffe000, v12
	v_dual_mov_b32 v78, 0 :: v_dual_and_b32 v13, 0xffffe000, v13
	v_dual_mov_b32 v83, 0 :: v_dual_and_b32 v14, 0xffffe000, v14
	v_dual_mov_b32 v82, 0 :: v_dual_and_b32 v15, 0xffffe000, v15
	v_dual_mov_b32 v87, 0 :: v_dual_and_b32 v0, 0xffffe000, v0
	v_dual_mov_b32 v86, 0 :: v_dual_and_b32 v1, 0xffffe000, v1
	v_dual_mov_b32 v91, 0 :: v_dual_and_b32 v2, 0xffffe000, v2
	v_dual_mov_b32 v90, 0 :: v_dual_and_b32 v3, 0xffffe000, v3
	v_dual_mov_b32 v95, 0 :: v_dual_and_b32 v4, 0xffffe000, v4
	v_dual_mov_b32 v94, 0 :: v_dual_and_b32 v5, 0xffffe000, v5
	v_dual_mov_b32 v99, 0 :: v_dual_and_b32 v6, 0xffffe000, v6
	v_dual_mov_b32 v98, 0 :: v_dual_and_b32 v7, 0xffffe000, v7
	s_wait_alu 0xfffe
	v_or_b32_e32 v41, s0, v41
	v_dual_max_num_f32 v100, v35, v35 :: v_dual_max_num_f32 v101, v37, v37
	s_lshl_b32 s33, s31, 10
	s_mov_b32 s31, 0xc3e00000
	v_cmp_neq_f32_e32 vcc_lo, 0, v35
	v_cmp_neq_f32_e64 s0, 0, v37
	v_max_num_f32_e32 v37, v39, v39
	v_cmp_neq_f32_e64 s1, 0, v39
	v_max_num_f32_e32 v39, v43, v43
	v_cmp_neq_f32_e64 s2, 0, v43
	v_max_num_f32_e32 v43, v45, v45
	v_cmp_neq_f32_e64 s3, 0, v45
	v_max_num_f32_e32 v45, v47, v47
	v_cmp_neq_f32_e64 s4, 0, v47
	v_max_num_f32_e32 v47, v49, v49
	v_cmp_neq_f32_e64 s5, 0, v49
	v_max_num_f32_e32 v49, v31, v31
	v_cmp_neq_f32_e64 s6, 0, v31
	v_max_num_f32_e32 v31, v16, v16
	v_cmp_neq_f32_e64 s7, 0, v16
	v_max_num_f32_e32 v16, v17, v17
	v_cmp_neq_f32_e64 s8, 0, v17
	v_max_num_f32_e32 v17, v18, v18
	v_cmp_neq_f32_e64 s9, 0, v18
	v_max_num_f32_e32 v18, v19, v19
	v_cmp_neq_f32_e64 s10, 0, v19
	v_max_num_f32_e32 v19, v20, v20
	v_cmp_neq_f32_e64 s11, 0, v20
	v_max_num_f32_e32 v20, v21, v21
	v_cmp_neq_f32_e64 s12, 0, v21
	v_max_num_f32_e32 v21, v22, v22
	v_cmp_neq_f32_e64 s13, 0, v22
	v_max_num_f32_e32 v22, v23, v23
	v_cmp_neq_f32_e64 s14, 0, v23
	v_max_num_f32_e32 v23, v8, v8
	v_cmp_neq_f32_e64 s15, 0, v8
	v_max_num_f32_e32 v8, v9, v9
	v_cmp_neq_f32_e64 s16, 0, v9
	v_max_num_f32_e32 v9, v10, v10
	v_cmp_neq_f32_e64 s17, 0, v10
	v_max_num_f32_e32 v10, v11, v11
	v_cmp_neq_f32_e64 s18, 0, v11
	v_max_num_f32_e32 v11, v12, v12
	v_cmp_neq_f32_e64 s19, 0, v12
	v_max_num_f32_e32 v12, v13, v13
	v_cmp_neq_f32_e64 s20, 0, v13
	v_max_num_f32_e32 v13, v14, v14
	v_cmp_neq_f32_e64 s21, 0, v14
	v_max_num_f32_e32 v14, v15, v15
	v_cmp_neq_f32_e64 s22, 0, v15
	v_max_num_f32_e32 v15, v0, v0
	v_cmp_neq_f32_e64 s23, 0, v0
	v_max_num_f32_e32 v0, v1, v1
	v_cmp_neq_f32_e64 s24, 0, v1
	v_max_num_f32_e32 v1, v2, v2
	v_cmp_neq_f32_e64 s25, 0, v2
	v_max_num_f32_e32 v2, v3, v3
	v_cmp_neq_f32_e64 s26, 0, v3
	v_max_num_f32_e32 v3, v4, v4
	v_cmp_neq_f32_e64 s27, 0, v4
	v_max_num_f32_e32 v4, v5, v5
	v_cmp_neq_f32_e64 s28, 0, v5
	v_max_num_f32_e32 v5, v6, v6
	v_cmp_neq_f32_e64 s29, 0, v6
	v_max_num_f32_e32 v6, v7, v7
	v_cmp_neq_f32_e64 s30, 0, v7
	v_lshlrev_b32_e32 v7, 9, v41
	s_wait_alu 0xfffe
	v_med3_num_f32 v41, v100, s31, 0x43e00000
	v_med3_num_f32 v0, v0, s31, 0x43e00000
	v_med3_num_f32 v100, v101, s31, 0x43e00000
	v_med3_num_f32 v37, v37, s31, 0x43e00000
	v_med3_num_f32 v39, v39, s31, 0x43e00000
	v_cvt_pk_fp8_f32 v36, v41, 0
	v_cvt_pk_fp8_f32 v87, v0, 0
	v_med3_num_f32 v43, v43, s31, 0x43e00000
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v51, 0
	s_delay_alu instid0(VALU_DEP_4)
	v_cvt_f32_fp8_e32 v0, v36
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v53, 0
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v57, 0
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v61, 0
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v65, 0
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v69, 0
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v73, 0
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v77, 0
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v81, 0
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v85, 0
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v89, 0
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v93, 0
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v97, 0
	v_med3_num_f32 v45, v45, s31, 0x43e00000
	v_med3_num_f32 v47, v47, s31, 0x43e00000
	v_med3_num_f32 v49, v49, s31, 0x43e00000
	v_med3_num_f32 v31, v31, s31, 0x43e00000
	v_med3_num_f32 v16, v16, s31, 0x43e00000
	v_med3_num_f32 v17, v17, s31, 0x43e00000
	v_med3_num_f32 v18, v18, s31, 0x43e00000
	v_med3_num_f32 v19, v19, s31, 0x43e00000
	v_med3_num_f32 v20, v20, s31, 0x43e00000
	v_med3_num_f32 v21, v21, s31, 0x43e00000
	v_med3_num_f32 v22, v22, s31, 0x43e00000
	v_med3_num_f32 v23, v23, s31, 0x43e00000
	v_med3_num_f32 v8, v8, s31, 0x43e00000
	v_med3_num_f32 v9, v9, s31, 0x43e00000
	v_med3_num_f32 v10, v10, s31, 0x43e00000
	v_med3_num_f32 v11, v11, s31, 0x43e00000
	v_med3_num_f32 v12, v12, s31, 0x43e00000
	v_med3_num_f32 v14, v14, s31, 0x43e00000
	v_med3_num_f32 v15, v15, s31, 0x43e00000
	v_med3_num_f32 v1, v1, s31, 0x43e00000
	v_med3_num_f32 v2, v2, s31, 0x43e00000
	v_med3_num_f32 v3, v3, s31, 0x43e00000
	v_med3_num_f32 v4, v4, s31, 0x43e00000
	v_med3_num_f32 v5, v5, s31, 0x43e00000
	v_med3_num_f32 v6, v6, s31, 0x43e00000
	s_wait_alu 0xfffd
	v_cndmask_b32_e32 v0, 0, v0, vcc_lo
	v_med3_num_f32 v13, v13, s31, 0x43e00000
	v_cvt_pk_fp8_f32 v38, v100, 0
	v_cvt_pk_fp8_f32 v42, v37, 0
	v_cvt_pk_fp8_f32 v44, v39, 0
	v_cvt_pk_fp8_f32 v46, v43, 0
	v_or_b32_e32 v35, v33, v40
	v_cvt_pk_fp8_f32 v48, v45, 0
	v_cvt_pk_fp8_f32 v50, v47, 0
	v_cvt_pk_fp8_f32 v51, v49, 0
	v_cvt_pk_fp8_f32 v53, v31, 0
	v_cvt_pk_fp8_f32 v55, v16, 0
	v_cvt_pk_fp8_f32 v57, v17, 0
	v_cvt_pk_fp8_f32 v59, v18, 0
	v_cvt_pk_fp8_f32 v61, v19, 0
	v_cvt_pk_fp8_f32 v63, v20, 0
	v_cvt_pk_fp8_f32 v65, v21, 0
	v_cvt_pk_fp8_f32 v67, v22, 0
	v_cvt_pk_fp8_f32 v69, v23, 0
	v_cvt_pk_fp8_f32 v71, v8, 0
	v_cvt_pk_fp8_f32 v73, v9, 0
	v_cvt_pk_fp8_f32 v75, v10, 0
	v_cvt_pk_fp8_f32 v77, v11, 0
	v_cvt_pk_fp8_f32 v79, v12, 0
	v_cvt_pk_fp8_f32 v81, v13, 0
	v_cvt_pk_fp8_f32 v83, v14, 0
	v_cvt_pk_fp8_f32 v85, v15, 0
	v_cvt_pk_fp8_f32 v89, v1, 0
	v_cvt_pk_fp8_f32 v91, v2, 0
	v_cvt_pk_fp8_f32 v93, v3, 0
	v_cvt_pk_fp8_f32 v95, v4, 0
	v_cvt_pk_fp8_f32 v97, v5, 0
	v_cvt_pk_fp8_f32 v99, v6, 0
	v_cvt_f32_fp8_e32 v1, v38
	v_cvt_f32_fp8_e32 v2, v42
	v_cvt_f32_fp8_e32 v3, v44
	v_cvt_f32_fp8_e32 v4, v46
	v_mov_b32_e32 v25, 0
	v_or3_b32 v34, v34, s33, v35
	v_or3_b32 v33, v7, v40, v33
	v_or_b32_e32 v7, v35, v7
	v_cvt_f32_fp8_e32 v5, v48
	v_cvt_f32_fp8_e32 v6, v50
	v_cvt_f32_fp8_e32 v8, v51
	v_cvt_f32_fp8_e32 v9, v53
	v_cvt_f32_fp8_e32 v10, v55
	v_cvt_f32_fp8_e32 v11, v57
	v_cvt_f32_fp8_e32 v12, v59
	v_cvt_f32_fp8_e32 v13, v61
	v_cvt_f32_fp8_e32 v14, v63
	v_cvt_f32_fp8_e32 v15, v65
	v_cvt_f32_fp8_e32 v16, v67
	v_cvt_f32_fp8_e32 v17, v69
	v_cvt_f32_fp8_e32 v18, v71
	v_cvt_f32_fp8_e32 v19, v73
	v_cvt_f32_fp8_e32 v20, v75
	v_cvt_f32_fp8_e32 v21, v77
	v_cvt_f32_fp8_e32 v22, v79
	v_cvt_f32_fp8_e32 v23, v81
	v_cvt_f32_fp8_e32 v31, v83
	v_cvt_f32_fp8_e32 v35, v85
	v_cvt_f32_fp8_e32 v36, v87
	v_cvt_f32_fp8_e32 v37, v89
	v_cvt_f32_fp8_e32 v38, v91
	v_cvt_f32_fp8_e32 v39, v93
	v_cvt_f32_fp8_e32 v40, v95
	v_cvt_f32_fp8_e32 v41, v97
	v_cvt_f32_fp8_e32 v42, v99
	s_wait_alu 0xf1ff
	v_cndmask_b32_e64 v1, 0, v1, s0
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0
	v_cndmask_b32_e64 v2, 0, v2, s1
	v_cndmask_b32_e64 v3, 0, v3, s2
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0
	v_cndmask_b32_e64 v4, 0, v4, s3
	v_cndmask_b32_e64 v5, 0, v5, s4
	v_cndmask_b32_e64 v6, 0, v6, s5
	v_cndmask_b32_e64 v8, 0, v8, s6
	v_cndmask_b32_e64 v9, 0, v9, s7
	v_cndmask_b32_e64 v10, 0, v10, s8
	v_cndmask_b32_e64 v11, 0, v11, s9
	v_cndmask_b32_e64 v12, 0, v12, s10
	v_cndmask_b32_e64 v13, 0, v13, s11
	v_cndmask_b32_e64 v14, 0, v14, s12
	v_cndmask_b32_e64 v15, 0, v15, s13
	v_cndmask_b32_e64 v16, 0, v16, s14
	v_cndmask_b32_e64 v17, 0, v17, s15
	v_cndmask_b32_e64 v18, 0, v18, s16
	v_cndmask_b32_e64 v19, 0, v19, s17
	v_cndmask_b32_e64 v20, 0, v20, s18
	v_cndmask_b32_e64 v21, 0, v21, s19
	v_cndmask_b32_e64 v22, 0, v22, s20
	v_cndmask_b32_e64 v23, 0, v23, s21
	v_cndmask_b32_e64 v31, 0, v31, s22
	v_cndmask_b32_e64 v35, 0, v35, s23
	v_cndmask_b32_e64 v36, 0, v36, s24
	v_cndmask_b32_e64 v37, 0, v37, s25
	v_cndmask_b32_e64 v38, 0, v38, s26
	v_cndmask_b32_e64 v39, 0, v39, s27
	v_cndmask_b32_e64 v40, 0, v40, s28
	v_cndmask_b32_e64 v41, 0, v41, s29
	v_cndmask_b32_e64 v42, 0, v42, s30
	v_cvt_pk_fp8_f32 v32, v0, 0
	v_cvt_pk_fp8_f32 v25, v1, 0
	v_cvt_pk_fp8_f32 v26, v2, 0
	v_cvt_pk_fp8_f32 v27, v3, 0
	v_cvt_pk_fp8_f32 v28, v4, 0
	v_cvt_pk_fp8_f32 v29, v5, 0
	v_cvt_pk_fp8_f32 v30, v6, 0
	v_cvt_pk_fp8_f32 v52, v8, 0
	v_cvt_pk_fp8_f32 v54, v9, 0
	v_cvt_pk_fp8_f32 v56, v10, 0
	v_cvt_pk_fp8_f32 v58, v11, 0
	v_cvt_pk_fp8_f32 v60, v12, 0
	v_cvt_pk_fp8_f32 v62, v13, 0
	v_cvt_pk_fp8_f32 v64, v14, 0
	v_cvt_pk_fp8_f32 v66, v15, 0
	v_cvt_pk_fp8_f32 v68, v16, 0
	v_cvt_pk_fp8_f32 v70, v17, 0
	v_cvt_pk_fp8_f32 v72, v18, 0
	v_cvt_pk_fp8_f32 v74, v19, 0
	v_cvt_pk_fp8_f32 v76, v20, 0
	v_cvt_pk_fp8_f32 v78, v21, 0
	v_cvt_pk_fp8_f32 v80, v22, 0
	v_cvt_pk_fp8_f32 v82, v23, 0
	v_cvt_pk_fp8_f32 v84, v31, 0
	v_cvt_pk_fp8_f32 v86, v35, 0
	v_cvt_pk_fp8_f32 v88, v36, 0
	v_cvt_pk_fp8_f32 v90, v37, 0
	v_cvt_pk_fp8_f32 v92, v38, 0
	v_cvt_pk_fp8_f32 v94, v39, 0
	v_cvt_pk_fp8_f32 v96, v40, 0
	v_cvt_pk_fp8_f32 v98, v41, 0
	v_cvt_pk_fp8_f32 v24, v42, 0
	s_clause 0x1f
	global_store_b8 v34, v32, s[34:35]
	global_store_b8 v34, v25, s[34:35] offset:32
	global_store_b8 v34, v26, s[34:35] offset:64
	global_store_b8 v34, v27, s[34:35] offset:96
	global_store_b8 v34, v28, s[34:35] offset:128
	global_store_b8 v34, v29, s[34:35] offset:160
	global_store_b8 v34, v30, s[34:35] offset:192
	global_store_b8 v34, v52, s[34:35] offset:224
	global_store_b8 v34, v54, s[34:35] offset:16
	global_store_b8 v34, v56, s[34:35] offset:48
	global_store_b8 v34, v58, s[34:35] offset:80
	global_store_b8 v34, v60, s[34:35] offset:112
	global_store_b8 v34, v62, s[34:35] offset:144
	global_store_b8 v34, v64, s[34:35] offset:176
	global_store_b8 v34, v66, s[34:35] offset:208
	global_store_b8 v34, v68, s[34:35] offset:240
	global_store_b8 v33, v70, s[34:35]
	global_store_b8 v33, v72, s[34:35] offset:32
	global_store_b8 v33, v74, s[34:35] offset:64
	global_store_b8 v33, v76, s[34:35] offset:96
	global_store_b8 v33, v78, s[34:35] offset:128
	global_store_b8 v33, v80, s[34:35] offset:160
	global_store_b8 v33, v82, s[34:35] offset:192
	global_store_b8 v33, v84, s[34:35] offset:224
	global_store_b8 v7, v86, s[34:35] offset:16
	global_store_b8 v7, v88, s[34:35] offset:48
	global_store_b8 v7, v90, s[34:35] offset:80
	global_store_b8 v7, v92, s[34:35] offset:112
	global_store_b8 v7, v94, s[34:35] offset:144
	global_store_b8 v7, v96, s[34:35] offset:176
	global_store_b8 v7, v98, s[34:35] offset:208
	global_store_b8 v7, v24, s[34:35] offset:240
.LBB79_6:
	s_nop 0
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel split_ffn_one_w2f8
		.amdhsa_group_segment_fixed_size 0
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 28
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_wavefront_size32 1
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 116
		.amdhsa_next_free_sgpr 40
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_fp16_overflow 0
		.amdhsa_workgroup_processor_mode 1
		.amdhsa_memory_ordered 1
		.amdhsa_forward_progress 1
		.amdhsa_inst_pref_size 52
		.amdhsa_round_robin_scheduling 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
